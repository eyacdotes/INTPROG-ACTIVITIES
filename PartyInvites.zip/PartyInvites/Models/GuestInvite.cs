﻿using System.ComponentModel.DataAnnotations;

namespace PartyInvites.Models
{
    public class GuestInvite
    {
        [Required(ErrorMessage = "Please enter Name. ")]
        public string? Name { get; set; }
        [Required(ErrorMessage = "Please input Email address. ")]
        public string? Email { get; set; }
        [Required(ErrorMessage = "Please enter Phone Number. ")]
        public string? Phone { get; set; }
        [Required(ErrorMessage = "Please select an answer. ")]
        public bool? WillAttend { get; set; }
    }
}
